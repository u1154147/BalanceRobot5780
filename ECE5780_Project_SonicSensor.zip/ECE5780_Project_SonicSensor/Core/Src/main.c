/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2021 STMicroelectronics.
  * All rights reserved.</center></h2>
  *
  * This software component is licensed by ST under BSD 3-Clause license,
  * the "License"; You may not use this file except in compliance with the
  * License. You may obtain a copy of the License at:
  *                        opensource.org/licenses/BSD-3-Clause
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"


#include <stdio.h>

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */

/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/

/* USER CODE BEGIN PV */

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
/* USER CODE BEGIN PFP */

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
	
	
volatile char global[3] = {'\0', '\0', '\0'};
volatile char take_val = 0;
volatile int flag = 0;
	
void TAKE_CHAR(char character) {
 
	while(!(USART3->ISR & (1 << 7))) {
	}
		
	USART3->TDR = character;
}	

void READ_CHAR_toggle(char color) {
	
	if(color == 'r') {
		GPIOC->ODR ^= (1 << 6);
		char string[26] = "SUCCESS, red LED toggled\r\n";
		for(int i = 0; i < 26; i++) {
			if(string[i] != 0)
				TAKE_CHAR(string[i]);
			else
				break;
		}
	}
	else if(color == 'b') {
		GPIOC->ODR ^= (1 << 7);
		char string[27] = "SUCCESS, blue LED toggled\r\n";
		for(int i = 0; i < 27; i++) {
			if(string[i] != 0)
				TAKE_CHAR(string[i]);
			else
				break;
		}
	}
	else if(color == 'o') {
		GPIOC->ODR ^= (1 << 8);
		char string[29] = "SUCCESS, orange LED toggled\r\n";
		for(int i = 0; i < 29; i++) {
			if(string[i] != 0)
				TAKE_CHAR(string[i]);
			else
				break;
		}
	}
	else if(color == 'g') {
		GPIOC->ODR ^= (1 << 9);
		char string[28] = "SUCCESS, green LED toggled\r\n";
		for(int i = 0; i < 28; i++) {
			if(string[i] != 0)
				TAKE_CHAR(string[i]);
			else
				break;
		}
	}
	else {
		char string[32] = "ERROR, no corresponding action\r\n";
		for(int i = 0; i < 32; i++) {
			if(string[i] != 0)
				TAKE_CHAR(string[i]);
			else
				break;
		}
	}	
	global[0] = '\0';
	global[1] = '\0';
	global[2] = '\0';
	flag = 0;
}
void READ_CHAR_on(char color) {
	
	if(color == 'r') {
		GPIOC->ODR |= (1 << 6);
		char string[22] = "SUCCESS, red LED on\r\n";
		for(int i = 0; i < 22; i++) {
			if(string[i] != 0)
				TAKE_CHAR(string[i]);
			else
				break;
		}
	}
	else if(color == 'b') {
		GPIOC->ODR |= (1 << 7);
		char string[23] = "SUCCESS, blue LED on\r\n";
		for(int i = 0; i < 23; i++) {
			if(string[i] != 0)
				TAKE_CHAR(string[i]);
			else
				break;
		}
	}
	else if(color == 'o') {
		GPIOC->ODR |= (1 << 8);
		char string[25] = "SUCCESS, orange LED on\r\n";
		for(int i = 0; i < 25; i++) {
			if(string[i] != 0)
				TAKE_CHAR(string[i]);
			else
				break;
		}
	}
	else if(color == 'g') {
		GPIOC->ODR |= (1 << 9);
		char string[24] = "SUCCESS, green LED on\r\n";
		for(int i = 0; i < 24; i++) {
			if(string[i] != 0)
				TAKE_CHAR(string[i]);
			else
				break;
		}
	}
	else {
		char string[32] = "ERROR, no corresponding action\r\n";
		for(int i = 0; i < 32; i++) {
				if(string[i] != 0)
					TAKE_CHAR(string[i]);
				else
					break;
		}
	}
	global[0] = '\0';
	global[1] = '\0';
	global[2] = '\0';
	flag = 0;
}

void READ_CHAR_off(char color) {
	
	if(color == 'r') {
		GPIOC->ODR &= ~(1 << 6);
		char string[22] = "SUCCESS, red LED off\r\n";
		for(int i = 0; i < 22; i++) {
			if(string[i] != 0)
				TAKE_CHAR(string[i]);
			else
				break;
		}
	}
	else if(color == 'b') {
		GPIOC->ODR &= ~(1 << 7);
		char string[23] = "SUCCESS, blue LED off\r\n";
		for(int i = 0; i < 23; i++) {
			if(string[i] != 0)
				TAKE_CHAR(string[i]);
			else
				break;
		}
	}
	else if(color == 'o') {
		GPIOC->ODR &= ~(1 << 8);
		char string[25] = "SUCCESS, orange LED off\r\n";
		for(int i = 0; i < 25; i++) {
			if(string[i] != 0)
				TAKE_CHAR(string[i]);
			else
				break;
		}
	}
	else if(color == 'g') {
		GPIOC->ODR &= ~(1 << 9);
		char string[24] = "SUCCESS, green LED off\r\n";
		for(int i = 0; i < 24; i++) {
			if(string[i] != 0)
				TAKE_CHAR(string[i]);
			else
				break;
		}
	}
	else {
			char string[32] = "ERROR, no corresponding action\r\n";
			for(int i = 0; i < 32; i++) {
				if(string[i] != 0)
					TAKE_CHAR(string[i]);
				else
					break;
			}
	}
	global[0] = '\0';
	global[1] = '\0';
	global[2] = '\0';
	flag = 0;
}
		




void usDelay(uint32_t uSec)
{
	if(uSec < 2) uSec = 2;
	TIM3->ARR = 10 * uSec - 1; 	/*sets the value in the auto-reload register*/
	TIM3->EGR = 1; 			/*Re-initialises the timer*/
	TIM3->PSC = 2-1;
	TIM3->SR &= ~1; 		//Resets the flag
	TIM3->CR1 |= 1; 		//Enables the counter
	while((TIM3->SR & 0x0001) != 1);
	TIM3->CR1 &= ~(1 << 1);
	
}



/*
static void MX_TIM3_Init(void)
{


  TIM_ClockConfigTypeDef sClockSourceConfig = {0};
  TIM_MasterConfigTypeDef sMasterConfig = {0};


  htim3.Instance = TIM3;
  htim3.Init.Prescaler = 8-1;  //OR 8-1 ???
  htim3.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim3.Init.Period = 0;
  htim3.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim3.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_Base_Init(&htim3) != HAL_OK)
  {
    Error_Handler();
  }
  sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
  if (HAL_TIM_ConfigClockSource(&htim3, &sClockSourceConfig) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim3, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }

}
*/



const float speedSound = 0.0343;
float distance;


int main(void)
{
	
	
		uint32_t ticks = 0;
  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */
//To initialize clock for USART
	RCC->APB1ENR |= RCC_APB1ENR_USART3EN;
	RCC->AHBENR |= RCC_AHBENR_GPIOCEN;
	RCC->AHBENR |= RCC_AHBENR_GPIOBEN;
	RCC->APB1ENR |= RCC_APB1ENR_TIM3EN; 

	
	//Enable LEDs for toggling use
	GPIOC->MODER |= ((1 << 12) | (1 << 14) | (1 << 16) | (1 << 18));
	
	//PB8 is trig output so set to output mode
	GPIOB->MODER |= (1 << 16);
	
	//Set PC10 and PC11 to alternate function modes
	//GPIOC->MODER |= ((1 << 21) | (1 << 23));

	//Set PC10 and PC11 to alternate functions AF1 which are USART3_TX and USART3_RX. Pretty sure writing 0001 or 0x01 does that
	//GPIOC->AFR[1] |= ((0x01 << GPIO_AFRH_AFSEL10_Pos) | (0x01 << GPIO_AFRH_AFSEL11_Pos)); 
	
	//Set Baud rate to 9600 to be like arduino I guess
	//USART3->BRR = HAL_RCC_GetHCLKFreq()/9600;
	
	//Enable transmit and receive bits 
	//USART3->CR1 |= ((1<<3)|(1<<2));
	
	//Enable USART
	//USART3->CR1 |= (1 << 0);
	
	//Setup interrupt
	//USART3->CR1|=(1<<5);
	//NVIC_EnableIRQ(USART3_4_IRQn);
  //NVIC_SetPriority(USART3_4_IRQn,1);	
	
	
	//Sets TIM3_PSC to value 7
	TIM3->PSC = 80-1;
	TIM3->CCER |= ((1 << 0) | (1 << 4));
	
	//Sets TIM3_ARR to value 1250  
	//TIM3->ARR = 1000;

	
  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  /* USER CODE BEGIN 2 */

  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
	
	//MX_GPIO_Init();
  //MX_TIM3_Init();
	
	
	
	
	
  while (1)
  {
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */

		GPIOB->ODR &= ~(8 << 1); //Trigger pin hold low
		usDelay(3);

		
		
		GPIOB->ODR |= (8 << 1); //Trigger pin hold high
		usDelay(5);
		GPIOB->ODR &= ~(8 << 1); //Trigger pin hold low
		
		
		while((GPIOB->ODR & (9 << 1)) == 0);
		
		ticks = 0;
		while((GPIOB->ODR & (9 << 1)) == 1) {
			ticks++;
			usDelay(2);
		}
		
		distance = (ticks + 0.0f)*2.8*(speedSound/2);
		
		if(distance > 300)
			GPIOC->ODR |= (1 << 6);
		else if(distance > 200)
			GPIOC->ODR |= (1 << 7);
		else if(distance > 100)
			GPIOC->ODR |= (1 << 8);	
		else if(distance > 2)
			GPIOC->ODR |= (1 << 9);	
		
		HAL_Delay(100); //Delay 100ms until next reading. This is above the recommended 60ms measurement cycle.
		
	}	
}

/*
void USART3_4_IRQHandler(void) {
	
	
	take_val = USART3->RDR;
	flag = 1;
}
*/


/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_NONE;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }
  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_HSI;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_0) != HAL_OK)
  {
    Error_Handler();
  }
}

/* USER CODE BEGIN 4 */

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/